import React, { Component } from 'react'

export default class ReportDetails extends Component {
	render() {
		return (
			<div>
					
			</div>
		)
	}
}
